@extends('layout.seclanding')
@section('content')
<div id="invoice">

</div>
@endsection
