@extends('layout.landing')
@section('content')
<div id="mycourse">

</div>
@endsection
