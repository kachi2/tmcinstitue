@extends('newdesign.layout.newindex')
@section('content')
<div id="newdash">
kjhkdhjdh
</div>
@endsection
