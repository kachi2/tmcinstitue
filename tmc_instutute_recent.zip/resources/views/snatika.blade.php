@extends('layout.landing')
@section('content')
<div id="snatika">
</div>
@endsection
